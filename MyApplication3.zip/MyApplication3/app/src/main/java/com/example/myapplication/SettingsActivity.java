package com.example.myapplication;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ArrayAdapter;
import android.widget.Toast;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;

public class SettingsActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        Button buttonResetData = findViewById(R.id.buttonResetData);
        Button buttonBack = findViewById(R.id.buttonBack);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.language_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        buttonResetData.setOnClickListener(v -> resetData());
        buttonBack.setOnClickListener(v -> finish());
    }

    private void resetData() {
        try (DatabaseHelper databaseHelper = new DatabaseHelper(this)) {
            databaseHelper.resetDatabase();
            Toast.makeText(this, "Данные успешно сброшены", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Ошибка при сбросе данных", Toast.LENGTH_SHORT).show();
            Log.e("SettingsActivity", "Ошибка при сбросе данных", e);
        }
    }
}
