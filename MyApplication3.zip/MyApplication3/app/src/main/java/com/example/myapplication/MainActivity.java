package com.example.myapplication;

import android.os.Bundle;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Button;
import android.widget.ArrayAdapter;
import java.util.ArrayList;
import android.content.Intent;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private TextView textViewTaskDetails;
    private ArrayAdapter<String> adapter;
    private ArrayList<String> taskList;
    private DatabaseHelper databaseHelper;
    private String selectedTask;
    private ActivityResultLauncher<Intent> addTaskLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ListView listViewTasks = findViewById(R.id.listViewTasks);
        textViewTaskDetails = findViewById(R.id.textViewTaskDetails);
        Button buttonDeleteTask = findViewById(R.id.buttonDeleteTask);
        Button buttonAddTask = findViewById(R.id.buttonAddTask);
        Button buttonSettings = findViewById(R.id.buttonSettings);
        Button buttonExit = findViewById(R.id.buttonExit);

        databaseHelper = new DatabaseHelper(this);
        taskList = databaseHelper.getAllTasks();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, taskList);
        listViewTasks.setAdapter(adapter);

        listViewTasks.setOnItemClickListener((parent, view, position, id) -> {
            selectedTask = taskList.get(position);
            textViewTaskDetails.setText(selectedTask);
        });

        buttonDeleteTask.setOnClickListener(v -> {
            if (selectedTask != null) {
                databaseHelper.deleteTask(selectedTask);
                taskList.remove(selectedTask);
                adapter.notifyDataSetChanged();
                textViewTaskDetails.setText("");
                selectedTask = null;
            }
        });

        addTaskLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK) {
                        Intent data = result.getData();
                        if (data != null) {
                            String newTask = data.getStringExtra("task");
                            taskList.add(newTask);
                            adapter.notifyDataSetChanged();
                        }
                    }
                }
        );

        buttonAddTask.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AddTaskActivity.class);
            addTaskLauncher.launch(intent);
        });

        buttonSettings.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, SettingsActivity.class);
            startActivity(intent);
        });

        buttonExit.setOnClickListener(v -> finish());
    }
}
