package com.example.myapplication;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.Toast;
import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;

public class AddTaskActivity extends AppCompatActivity {
    private EditText editTextTaskName, editTextTaskDescription;
    private DatePicker datePicker;
    private Spinner spinnerPriority;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_task);

        editTextTaskName = findViewById(R.id.editTextTaskName);
        editTextTaskDescription = findViewById(R.id.editTextTaskDescription);
        datePicker = findViewById(R.id.datePicker);
        spinnerPriority = findViewById(R.id.spinnerPriority);
        Button buttonSave = findViewById(R.id.buttonSave);
        Button buttonHome = findViewById(R.id.buttonHome);

        databaseHelper = new DatabaseHelper(this);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.priority_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerPriority.setAdapter(adapter);

        buttonSave.setOnClickListener(v -> saveTask());
        buttonHome.setOnClickListener(v -> finish());
    }

    private void saveTask() {
        String taskName = editTextTaskName.getText().toString();
        String taskDescription = editTextTaskDescription.getText().toString();
        int day = datePicker.getDayOfMonth();
        int month = datePicker.getMonth();
        int year = datePicker.getYear();
        String dueDate = day + "/" + (month + 1) + "/" + year;
        int priority = Integer.parseInt(spinnerPriority.getSelectedItem().toString());

        if (taskName.isEmpty()) {
            Toast.makeText(this, "Введите название задачи", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean isInserted = databaseHelper.insertTask(taskName, taskDescription, dueDate, priority);
        if (isInserted) {
            Toast.makeText(this, "Задача успешно сохранена", Toast.LENGTH_SHORT).show();
            Intent returnIntent = new Intent();
            returnIntent.putExtra("task", taskName);
            setResult(RESULT_OK, returnIntent);
            finish();
        } else {
            Toast.makeText(this, "Ошибка при сохранении задачи", Toast.LENGTH_SHORT).show();
        }
    }
}
