package com.example.password;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import java.util.List;

public class PasswordAdapter extends ArrayAdapter<PasswordEntry> {
    public PasswordAdapter(Context context, List<PasswordEntry> passwords) {
        super(context, 0, passwords);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        PasswordEntry passwordEntry = getItem(position);

        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(android.R.layout.simple_list_item_2, parent, false);
        }

        TextView textViewService = convertView.findViewById(android.R.id.text1);
        TextView textViewUsername = convertView.findViewById(android.R.id.text2);

        assert passwordEntry != null;
        textViewService.setText(passwordEntry.getServiceName());
        textViewUsername.setText(passwordEntry.getUsername());

        convertView.setOnClickListener(v -> {
            Intent intent = new Intent(getContext(), PasswordDetailActivity.class);
            intent.putExtra("passwordEntry", passwordEntry);
            getContext().startActivity(intent);
        });

        return convertView;
    }
}
