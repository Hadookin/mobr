package com.example.password;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class AddPasswordActivity extends AppCompatActivity {

    private EditText editTextService, editTextLogin, editTextPassword;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_password);

        editTextService = findViewById(R.id.editTextService);
        editTextLogin = findViewById(R.id.editTextLogin);
        editTextPassword = findViewById(R.id.editTextPassword);
        Button buttonSave = findViewById(R.id.buttonSave);
        sharedPreferences = getSharedPreferences("User   Prefs", MODE_PRIVATE);

        buttonSave.setOnClickListener(v -> savePassword());
    }

    private void savePassword() {
        String service = editTextService.getText().toString();
        String login = editTextLogin.getText().toString();
        String password = editTextPassword.getText().toString();

        if (service.isEmpty() || login.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Все поля обязательны для заполнения", Toast.LENGTH_SHORT).show();
            return;
        }

        // Сохранение пароля в SharedPreferences
        sharedPreferences.edit().putString(service, login + ":" + password).apply();
        Toast.makeText(this, "Пароль успешно сохранён", Toast.LENGTH_SHORT).show();

        // Возврат на главный экран
        finish();
    }
}
