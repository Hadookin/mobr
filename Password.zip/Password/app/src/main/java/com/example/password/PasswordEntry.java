package com.example.password;
import java.io.Serializable;

public class PasswordEntry implements Serializable {
    private String serviceName;
    private String username;
    private String password;

    public PasswordEntry(String serviceName, String username, String password) {
        this.serviceName = serviceName;
        this.username = username;
        this.password = password;
    }

    public String getServiceName() {
        return serviceName;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }
}
