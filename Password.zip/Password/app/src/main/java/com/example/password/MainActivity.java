package com.example.password;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import com.google.gson.Gson;
import java.util.ArrayList;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    private final ArrayList<PasswordEntry> originalPasswordEntries = new ArrayList<>();
    private PasswordAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ListView listView = findViewById(R.id.listView);
        EditText searchEditText = findViewById(R.id.searchEditText);
        Button buttonAddPassword = findViewById(R.id.buttonAddPassword);

        loadPasswords();
        adapter = new PasswordAdapter(this, originalPasswordEntries);
        listView.setAdapter(adapter);

        searchEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                filterPasswords(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        buttonAddPassword.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AddPasswordActivity.class);
            startActivity(intent);
        });
    }

    private void loadPasswords() {
        SharedPreferences sharedPreferences = getSharedPreferences("passwords", MODE_PRIVATE);
        Map<String, ?> allEntries = sharedPreferences.getAll();
        Gson gson = new Gson();

        for (Map.Entry<String, ?> entry : allEntries.entrySet()) {
            String json = (String) entry.getValue();
            PasswordEntry passwordEntry = gson.fromJson(json, PasswordEntry.class);
            originalPasswordEntries.add(passwordEntry);
        }
    }

    private void filterPasswords(String query) {
        ArrayList<PasswordEntry> filteredList = new ArrayList<>();
        for (PasswordEntry entry : originalPasswordEntries) {
            if (entry.getServiceName().toLowerCase().contains(query.toLowerCase())) {
                filteredList.add(entry);
            }
        }
        adapter.clear();
        adapter.addAll(filteredList);
        adapter.notifyDataSetChanged();
    }
}
